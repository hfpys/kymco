<a href="https://github.com/yanhaijing/fan1xia">
  <img src="./images/fan.gif" width="100px">
</a>

#[Fan1xia](https://github.com/yanhaijing/fan1xia) [![license](http://img.shields.io/npm/l/express.svg)](https://github.com/yanhaijing/fan1xia/blob/master/MIT-LICENSE.txt)

fan1xia is a game like window 7's little games work on chrome/firefox/opera/ie10+ 

##Platform

* firefox
* chrome
* opera
* safira
* ie8+

##Demo

[http://yanhaijing.github.com/fan1xia](http://yanhaijing.github.com/fan1xia)

##Issues

[Report a Problem](https://github.com/yanhaijing/fan1xia/issues)

##Authors

**yanhaijing**

- [Twitter](http://t.qq.com/yanhaijing1234 "yanhaijing's Twitter")
- [Email](http://yanhaijing1234@gmail.com "yanhaijing's Email")

##Copyright and license

Copyright © 2013 yanhaijing. All Rights Reserved

Licensed under the MIT-LICENSE;
you may not use this work except in compliance with the License.
You may obtain a copy of the License in the LICENSE file, or at:
	[http://opensource.org/licenses/MIT](http://opensource.org/licenses/MIT)
	
**note:** Some pictures from Google and Microsoft, so they authorized in use 
