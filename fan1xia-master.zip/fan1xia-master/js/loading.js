(function($, global){
    "use strict";
    $(window).bind("load", function(){
        $("#loading").fadeOut();
    });           
}(jQuery, window));
